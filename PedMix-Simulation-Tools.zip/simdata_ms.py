__author__ = 'pjweggy'

from numpy import *
import re
from subprocess import *
import os

def reducedata(prefix,tol):
    input=prefix+'_org.dat'
    Recomfile=prefix+'_Recom.dat'
    Seq = loadtxt(input)
    Recom = loadtxt(Recomfile)
    nr,nc=Seq.shape
    col=list()
    freqpop1=sum(Seq[0:nr/2],axis=0)/float(nr/2)
    freqpop2=sum(Seq[nr/2:nr],axis=0)/float(nr/2)

    for i in range(nc):
        if abs(freqpop1[i]-freqpop2[i]) >= tol:
            col.append(i)
    #print col
    #print Seq[:,[0,2]]
    savetxt(prefix+'_rdc.dat',Seq[:,col],fmt='%d',delimiter=' ')
    savetxt(prefix+'_Recomrdc.dat',Recom[:,col],fmt='%.10f',delimiter=' ')


def msrun(mspath,prefix,nsam,nrep,mu,pho,ll,nsam1,nsam2,t_split):
    cmd = mspath+'ms {0} {1} -t {2} -r {3} {4} -I 2 {5} {6} -ej {7} 1 2'.format(nsam,nrep,mu,pho,ll,nsam1,nsam2,t_split)+' > '+prefix+'.ms'
    Popen(cmd, shell = True, stdout = PIPE).communicate()
    while not os.path.exists(prefix+'.ms'):
        continue

def macsrun(mspath,prefix,nsam,nrep,mu,pho,ll,nsam1,nsam2,t_split,hotspotfile):
    cmd = mspath+'macs {0} {1} -i {2} -t {3} -r {4} -R {5} -I 2 {6} {7} -ej {8} 1 2'.format(nsam,ll,nrep,mu,pho,hotspotfile,nsam1,nsam2,t_split)+' 2>'+prefix+'_trees.txt 1>'+prefix+'.macs'
    Popen(cmd, shell = True, stdout = PIPE).communicate()
    while not os.path.exists(prefix+'.macs'):
        continue
    cmd1 = mspath+'msformatter <'+prefix+'.macs >'+prefix+'.ms'
    Popen(cmd1, shell = True, stdout = PIPE).communicate()
    while not os.path.exists(prefix+'.ms'):
        continue


def Getinfo_ms(filename,Seq,Recomfrag,ACPaint):
##return two arrays: 2-dim haplotype matrix & recombination sites
    f=open(filename)
    rep_c = 0
    AnSeq = []
    for line in f:

        if line[0:2] == '//':
            if size(AnSeq) > 0:
                Seq[key] = array(AnSeq)
                nr,nc = AnSeq.shape
                AP = vstack((zeros((nr/2,nc)),ones((nr/2,nc))))
                ACPaint[key] = array((AP))
                AnSeq = []
            key='generation-0-locus-'+str(rep_c)
            rep_c += 1


        elif re.match('[0|1]+$',line):
            temp=list()
            for c in line[:-1]:
                temp.append(int(c))
            if size(AnSeq)==0:
                AnSeq=temp
            else:
                AnSeq=vstack((AnSeq,temp))

        elif line[0:4]=='posi':
            recomfrac=line.split()[1:]
            for i in range(len(recomfrac)):
                recomfrac[i]=float(recomfrac[i])
            Recomfrag[key] = recomfrac
            #print temp
    Seq[key] = array(AnSeq)
    nr,nc = AnSeq.shape
    AP = vstack((zeros((nr/2,nc)),ones((nr/2,nc))))
    ACPaint[key] = array((AP))
    f.close()
    return Seq,Recomfrag,ACPaint

##re-arrange AncSeq with order of gender Nf and Nm
def Getfounder(AncSeq):
    nr,nc=AncSeq.shape
    nr=nr/2
    AP=vstack((zeros((nr,nc)),ones((nr,nc))))
    gender=[0]*nr+[1]*nr
    random.shuffle(gender)
    gd_indx=argsort(gender)
    AncSeq=AncSeq[gd_indx]
    AP=AP[gd_indx]
    return AncSeq,AP

def Dump(Dict):
    for key in Dict:
        print key
        print Dict[key]








