_author__ = 'pjweggy'

import numpy as np
import sys
import random
import os


prefix=sys.argv[1]

nchr=22
nindv=500


def GetFrequency(prefix,freqpop,startindv,nchr,nindv):
    for i in range(startindv,(startindv+nindv/2),1):
        if i == startindv:
            F_sum=np.loadtxt(prefix+'_indv'+str(i+1)+'_gen0_Seq.dat')
        else:
            temp=np.loadtxt(prefix+'_indv'+str(i+1)+'_gen0_Seq.dat')
            F_sum=F_sum+temp

    nc=F_sum.shape[1]
    for i in range(nchr): # i chrom
        temp=list()
        for j in range(nc): # j snp
            line=2*i
            temp.append(float(F_sum[line,j]+F_sum[line+1,j])/float(nindv))
        if i == 0:
            Freq=temp
            del temp
        else:
            Freq=np.vstack((Freq,temp))
    np.savetxt(prefix+'_pop'+freqpop+'.freq',Freq,fmt='%.4f')

def GenPedMixInput(prefix,idx,Freqpop1,Freqpop2,Recomfrag,nchr,phopara,switchonoff,ll,Ng):
    f=open(prefix+'_indv'+str(idx+1)+'_gen'+str(Ng)+'PedMix.inp','ab')
    Seq=np.loadtxt(prefix+'_indv'+str(idx+1)+'_gen'+str(Ng)+'_Seq.dat')
    for i in range(nchr):
        f.write('//\n')
        if Freqpop1.ndim == 1:
            nc=len(Freqpop1)
        else:
            nc=Freqpop1.shape[1]
        PedMixinp=np.ones((1,nc))
        if Freqpop1.ndim == 1:
            PedMixinp=np.vstack((PedMixinp,Freqpop1))
            PedMixinp=np.vstack((PedMixinp,Freqpop2))
        else:
            PedMixinp=np.vstack((PedMixinp,Freqpop1[i]))
            PedMixinp=np.vstack((PedMixinp,Freqpop2[i]))
        recompos=list()
        for j in range(nc-1):
            if Recomfrag.ndim == 1:
                recompos.append((Recomfrag[j+1]-Recomfrag[j])*phopara)
            else:
                recompos.append((Recomfrag[i,j+1]-Recomfrag[i,j])*phopara)
        recompos.append(0.0000000)
        PedMixinp=np.vstack((PedMixinp,recompos))
        Dseq=Seq[2*i:2*(i+1),]
        if switchonoff==1:
            Dseq = Shuffle(Dseq,ll,Recomfrag[i],nchr)
        PedMixinp=np.vstack((PedMixinp,Dseq))
        patt='%d %.4f %.4f %.10f %d %d'
        PedMixinp=PedMixinp.T
        np.savetxt(f,PedMixinp,fmt=patt,newline='\n')
    f.close()

def Shuffle(Dseq,ll,Recomlist,nchr):
    swunitprob = 0.00002
    nr,nc = Dseq.shape
    Dseq_temp = list()
    for i in range(nr/2):
        h1 = list()
        h2 = list()
        indx = 0 #0 left haplotype
        scc=0
        for j in range(nc):
            r=random.uniform(0,1)
            if j==0:
                swprob=swunitprob*Recomlist[j]*ll*nchr
            elif (Recomlist[j]-Recomlist[j-1])==0:
                swprob=swunitprob
            else:
                swprob=swunitprob*(Recomlist[j]-Recomlist[j-1])*ll*nchr
            if r<=swprob:
                indx = 1-indx
                scc += 1
            h1.append(Dseq[2*i+indx,j])
            h2.append(Dseq[(2*i+1-indx),j])
        if np.size(Dseq_temp) == 0:
            Dseq_temp=np.vstack((h1,h2))
        else:
            Dseq_temp=np.vstack((Dseq_temp,h1))
            Dseq_temp=np.vstack((Dseq_temp,h2))
        print 'Individual {0} switched {1} times'.format(i,scc)
    return Dseq_temp

def writemixratio_geno(f,mixratio):
    f.write('Overall mix ratio is : [')
    if isinstance(mixratio,list):
        nc = len(mixratio)
        mratio = mixratio
    else:
        nc = mixratio.shape[1]
        mratio = np.mean(mixratio, axis=0)
    for i in range(nc/2):
        f.write(str(100.0-round(100*(mratio[2*i]+mratio[2*i+1])/2,4))+' ')
#        print str(round(100*(mratio[2*i]+mratio[2*i+1])/2,4))+' '
    f.write(']\n')

def writePP_geno(f,PP,ll):
    #print PP
    f.write('Overall PP info is : [')
    if isinstance(PP,list):
        nc=len(PP)
        PPT=PP
    else:
        nc = PP.shape[1]
        PPT = PP.sum(axis=0)
    for i in range(nc/8):
        if (PPT[8*i+1]+PPT[8*i+5]) == 0:
            f.write(str(round(1,8)))
        else:
            f.write(str(round((PPT[8*i]+PPT[8*i+4])/(ll*(PPT[8*i+1]+PPT[8*i+5])),8))+' ')
        if (PPT[8*i+3]+PPT[8*i+7]) == 0 :
            f.write(str(round(1,8))+' ')
        else:
            f.write(str(round((PPT[8*i+2]+PPT[8*i+6])/(ll*(PPT[8*i+3]+PPT[8*i+7])),8))+' ')
    f.write(']\n')

def GetMixRatio(ACmat,recomfrag):
    #mixratio = sum(ACmat,axis=1)/ACmat.shape[1]
    mixratio = list()
    nr,nc = ACmat.shape
    for i in range(nr):
        ll = 0.0
        for j in range(nc):
            if ACmat[i,j] == 1:
                if j > 0 :
                    ll += recomfrag[j]-recomfrag[j-1]
                elif j == 0:
                    ll += 0
        mixratio.append(ll/(recomfrag[-1]-recomfrag[0]))
    return mixratio

def GetPPinfo(ACmat,recomfrag):
    PP = list()
    nr,nc = ACmat.shape
    for i in range(nr):
        ll0 = 0.0
        ll1 = 0.0
        cc0to1=1
        cc1to0=1
        pre_site=2
        for j in range(nc):
            if ACmat[i,j] == 0:
                if pre_site == 1:
                    cc1to0 += 1
                if j > 0 :
                    ll0 += recomfrag[j]-recomfrag[j-1]
                elif j == 0:
                    ll0 += 0

            elif ACmat[i,j] == 1:
                if j > 0 :
                    ll1 += recomfrag[j]-recomfrag[j-1]
                elif j == 0:
                    ll1 += 0
                if pre_site == 0:
                    cc0to1 += 1
            pre_site = ACmat[i,j]
        PP.append(cc0to1)
        PP.append(ll0/(recomfrag[-1]-recomfrag[0]))
        PP.append(cc1to0)
        PP.append(ll1/(recomfrag[-1]-recomfrag[0]))
    return PP

def GetAncestryInfo(prefix,idx,Recomfrag,gen,Ng,nchr,ll):
    if os.path.exists(prefix+'_indv'+str(idx+1)+'_gen'+str(Ng)+'_sample.info'):
        os.remove(prefix+'_indv'+str(idx+1)+'_gen'+str(Ng)+'_sample.info')
    #Parent 10 * 1000 range[0-499]
    Parent=np.loadtxt(prefix+'_Parent.dat')
    f = open(prefix+'_indv'+str(idx+1)+'_gen'+str(Ng)+'_sample.info','ab')

    hapchecklist = list()
    hapchecklist.append(idx) #use indv idx to get genotype
    f.write('====================================\nIndividual {0} is choose to estimate\n'.format(idx))
    for i in range(gen+1):
        mixratio = list()
        PP = list()
        Seq=dict()
        for indv in hapchecklist:
            seq=np.loadtxt(prefix+'_indv'+str(int(indv+1))+'_gen'+str(Ng-i)+'_AP.dat') #get indv+1 AP at generation Ng-i
            key='indv'+str(indv+1)+'-gen'+str(Ng-i)
            Seq[key]=np.array(seq)
        for j in range(nchr):
            f.write('At chr {1}, {0} generation ago, Ancestry painting is\n'.format(i,j))
            ACmat=GetACmatfromSeq(Seq,hapchecklist,Ng,i,j)
            if Recomfrag.ndim == 1:
                recomfrag = Recomfrag
            else:
                recomfrag = Recomfrag[j]
            np.savetxt(f,ACmat,fmt='%d',newline='\n')
            if np.size(mixratio) == 0 :
                mixratio = GetMixRatio(ACmat,recomfrag)
                PP = GetPPinfo(ACmat,recomfrag)
            else:
                mixratio = np.vstack((mixratio,GetMixRatio(ACmat,recomfrag)))
                PP = np.vstack((PP,GetPPinfo(ACmat,recomfrag)))
        writemixratio_geno(f,mixratio)
        writePP_geno(f,PP,ll)
        pplist = list()
        for indv in hapchecklist:
            pplist.append(Parent[Ng-i-1][2*indv])
            pplist.append(Parent[Ng-i-1][2*indv+1])
        hapchecklist = pplist
        del pplist
    f.close()

def GetACmatfromSeq(Seq,hapchecklist,Ng,i,j):
    ACmat=list()
    for indv in hapchecklist:
        key='indv'+str(indv+1)+'-gen'+str(Ng-i)
        if np.size(ACmat)==0:
            ACmat=Seq[key][2*j:2*(j+1),]
        else:
            ACmat=np.vstack((ACmat,Seq[key][2*j:2*(j+1),]))
    return ACmat

freqpop=str(1)
startindv=0 #pop1 0 pop2 nindv/2

GetFrequency(prefix,freqpop,startindv,nchr,nindv)

freqpop=str(2)
startindv=nindv/2 #pop1 0 pop2 nindv/2

GetFrequency(prefix,freqpop,startindv,nchr,nindv)

Freqpop1=np.loadtxt(prefix+'_pop1.freq')
Freqpop2=np.loadtxt(prefix+'_pop2.freq')
Recomfrag=np.loadtxt(prefix+'_Recomrdc_reshape.dat')

#gen=3
Nsam = 10 ##number of samples to extract from simulation
genolist=list()
genolist=random.sample(range(nindv),Nsam)

print "Get samples:"
print genolist+[1]*len(genolist)

ll = 136360000
Ng=0
Ne=10000
r = 0.0004
######!!!!!!!!!!!!!!!!!!!!!!try larger recombination rate
pho = float(r)/(4*Ne) ##recombination rate:f() of r,ll; different for ms and macs: ms use r=4Ne*ll*pho, macs use r=4Ne*pho
toll=3000000000
phopara=pho*toll



#for i in range(250):
#    genolist.append(i)
#print genolist


for i in genolist:
    GenPedMixInput(prefix,i,Freqpop1,Freqpop2,Recomfrag,nchr,phopara,0,ll,Ng)
#    print i

'''
for indv in genolist:
    GetAncestryInfo(prefix,indv,Recomfrag,gen,Ng,nchr,ll)
#    print indv
'''
