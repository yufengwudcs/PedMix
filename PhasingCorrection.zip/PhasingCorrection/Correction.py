import sys

prefix = sys.argv[1]
num = int(sys.argv[2])

for l in range(1, num+1):	
	with open('./'+str(l)+'_Processing.txt', 'r') as f:
		data = []
		for x in f.readlines():
			x = x.strip('\n')
			x = x.split(' ')
			data.append(x)
	YC = 0
	CY = 0
	PsY = []
	PsC = []
	temp = 0
	tempC = 'A'
	for i in range(0,len(data)):
		if data[i][0] == "//":
			YC = 0
			CY = 0
			PsY = []
			PsC = []
			temp = 0
			tempC = 'A'
			continue
		if data[i][6] != data[i][7]:
			if data[i][6] == 'Y':
				YC += 1
				PsY.append(i)
			elif data[i][6] == 'C':
				CY += 1
				PsC.append(i)
		
		if data[i][6] == data[i][7]:
			if (YC != 0 and CY != 0):
				if YC >= CY:
					for j in range(0,len(PsC)):
						temp = data[PsC[j]][4]
						data[PsC[j]][4] = data[PsC[j]][5]
						data[PsC[j]][5] = temp
						tempC = data[PsC[j]][6]
						data[PsC[j]][6] = data[PsC[j]][7]
						data[PsC[j]][7] = tempC
					PsY = []
					PsC = []
					YC = 0
					CY = 0
				elif YC < CY:
					for j in range(0,len(PsY)):
						temp = data[PsY[j]][4]
						data[PsY[j]][4] = data[PsY[j]][5]
						data[PsY[j]][5] = temp
						tempC = data[PsY[j]][6]
						data[PsY[j]][6] = data[PsY[j]][7]
						data[PsY[j]][7] = tempC
					PsY = []
					PsC = []
					YC = 0
					CY = 0
	with open('./'+str(prefix)+'_Correction_'+str(l)+'.inp', 'w') as f2:
		for w in range(0, len(data)):
			if(data[w][0] == "//"):
				f2.write("//\n")
			else:
				f2.write("%d %f %f %.12f %d %d\n" % (int(data[w][0]), float(data[w][1]), float(data[w][2]), float(data[w][3]), int(data[w][4]), int(data[w][5])))
