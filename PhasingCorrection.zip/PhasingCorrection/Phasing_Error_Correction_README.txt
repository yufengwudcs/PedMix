To run this Correction program, just type:
./Correction.sh inputfile_prefix number_of_inputfile

The inputfile is the inputfile of PedMix, where each row corresponds to one SNP in an individual. Each row should be space-delimited and contains the following fields: SNP's type, allele frequency of population 1, allele frequency of population 2, length in CentiMorgan from last SNP to next SNP, haplotype 1 of the individual, and haplotype 2 of the individual. The inputfile must be renamed as "Prefix_number". For example, the prefix is "Example_Original" and the number of inputfile is "1 and 2" in this example.

The number_of_inputfile is the total number of individuals. For example, there are 2 individuals in this example, thus the number_of_inputfile should be 2. 

To run the example file, type:
./Correction.sh Example_Original 2

The example file takes a few seconds to run. 
