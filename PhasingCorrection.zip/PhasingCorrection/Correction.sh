#!/bin/bash
#Author: Yiming Zhang

prefix=$1
num=$2

for((i=1;i<=$2;i++));
do
	awk '{
		if ($1 == "//"){
			print $0 > "'${i}'_Processing.txt";
		}
		if ($5==$6){
			if($5==0 && $6==0){
				if($2>=$3){
					print $0, "Y", "Y" > "'${i}'_Processing.txt";
				}
				else if($2<$3){
					print $0, "C", "C" > "'${i}'_Processing.txt";
				}
			}
			else if($5==1 && $6==1){
				if($2>=$3){
					print $0, "C", "C" > "'${i}'_Processing.txt";
				}
				else if($2<$3){
					print $0, "Y", "Y" > "'${i}'_Processing.txt";
				}
			}
		}
		if ($5!=$6){
			if($5==1 && $6==0){
				if($2>=$3){
					print $0, "C", "Y" > "'${i}'_Processing.txt";
				}
				else if($2<$3){
					print $0, "Y", "C" > "'${i}'_Processing.txt";
				}
			}
			else if($5==0 && $6==1){
				if($2>=$3){
					print $0, "Y", "C" > "'${i}'_Processing.txt";
				}
				else if($2<$3){
					print $0, "C", "Y" > "'${i}'_Processing.txt";
				}
			}
		}
	}' "$prefix"_${i}.inp
done
echo "Processing Done"

python Correction.py $prefix $num

for((i=1;i<=$2;i++));
do
	rm ${i}_Processing.txt
done
echo "Correction Done"
