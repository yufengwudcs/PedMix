To run this Trimming program, just type:
python DF_Pruning.py -i input_filename -o output_filename -n threshold 

The input is the input file of PedMix, where each row corresponds to one SNP in an individual. Each row should be space-delimited and contains the following fields: SNP's type, allele frequency of population 1, allele frequency of population 2, length in CentiMorgan from last SNP to next SNP, haplotype 1 of the individual, and haplotype 2 of the individual.

The output is the output file of PedMix after trimming. This file can be used by PedMix directly.

The threshold is a number for trimming, and the best threshold of trimming is 0.4 based on our experiments.  

To run the example file, type:
python DF_Pruning.py -i Example_Original.inp -o Example_Pruning.inp -n 0.4

The help information can be found by typing:
python DF_Pruning.py -h
