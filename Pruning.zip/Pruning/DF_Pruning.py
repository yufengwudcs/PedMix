#Author: Yiming Zhang

import numpy as np
import sys, getopt

def main(argv):
	inputfile = ''
	outputfile = ''
	threshold = 0.0
	try:
		opts, args = getopt.getopt(argv,"hi:o:n:",["help","ifile=","ofile=","thold="])
	except getopt.GetoptError:
		print 'Usage: python DF_Prunning.py -i <inputfile> -o <outputfile> -n <threshold>'
		sys.exit(2)
	if len(opts) != 3 and opts[0][0] != '-h':
		print 'Usage: python DF_Prunning.py -i <inputfile> -o <outputfile> -n <threshold>'
		sys.exit()
	for opt, arg in opts:
		if opt == '-h':
			print 'Usage: python DF_Prunning.py -i <inputfile> -o <outputfile> -n <threshold>'
			sys.exit()
		elif opt in ("-i", "--ifile"):
			inputfile = arg
		elif opt in ("-o", "--ofile"):
			outputfile = arg
		elif opt in ("-n", "--thold"):
			threshold = arg
	return inputfile, outputfile, threshold


if __name__ == "__main__":
	main(sys.argv[1:])

inputfile, outputfile, threshold = main(sys.argv[1:])

print 'Begin Pruning'

f = open('./'+inputfile, 'r')
f1 = open('./'+outputfile, 'w')
x = f.readline()
for i in range(22):
	f1.write('//\n')
	data = []
	data_df = []
	gmap = 0.0
	x = f.readline()
	while x:
		if(x=='//\n'):
			break
		else:
			x = x.strip('\n')
			x = x.split(' ')
			data.append(x)
			x = f.readline()
	for j in range(len(data)):
		if(abs(float(data[j][1])-float(data[j][2])) >= float(threshold)):
			if(len(data_df)):
				data_df[-1][3] = float(data_df[-1][3]) + gmap
				data_df.append(data[j])
				gmap = 0.0
			else:
				data_df.append(data[j])
				gmap = 0.0
		else:
			gmap += float(data[j][3])
	for s in range(len(data_df)):
		if(s==len(data_df)-1):
			f1.write('%d %.3f %.3f 0.000000000000 %d %d\n' % (int(data_df[s][0]),float(data_df[s][1]),float(data_df[s][2]),int(data_df[s][4]),int(data_df[s][5])))
		else:		
			f1.write('%d %.3f %.3f %.12f %d %d\n' % (int(data_df[s][0]),float(data_df[s][1]),float(data_df[s][2]),float(data_df[s][3]),int(data_df[s][4]),int(data_df[s][5])))
		
f.close()
f1.close()
print 'Done'
