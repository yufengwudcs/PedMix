#### This is the time line for PedMix work ####
Step:
* revise PedMix codei: 1st Milestone (Nov18-Dec1)
* rerun all simulation: 2nd Milestone (Dec2-Dec29)
* real data analysis: 3rd Milestone (Dec30-Feb2)
** Manuscript:Yufeng Wu

#### 
1st Milestone (Nov18-Dec1)
* check code structure
* output posterior probability
* add this step to code
