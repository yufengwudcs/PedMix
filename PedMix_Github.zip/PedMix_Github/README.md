# PedMix
./PedMix -g 1 -p parfile testPedMix.inp 

For more details, please see PedMix-tutorial.pdf
